====================================================
  TUTORCONNECT — Final Year Project
  Developed by: Monisha S
====================================================

PROJECT OVERVIEW
----------------
TutorConnect is a web-based tutor booking platform that
connects students with expert tutors. It features role-based
access for Students, Tutors, and an Admin (Monisha S).

HOW TO RUN THE APP
------------------
1. Open the folder called "app"
2. Double-click the file "index.html"
3. It will open in your web browser (Chrome recommended)
4. No internet connection required after the page loads
   (fonts load from Google Fonts if online)

HOW TO USE
----------
- Use the role switcher in the top-right navbar to switch
  between Student, Tutor, and Admin views.

STUDENT:
  - Browse and search for tutors
  - Click a tutor card to view their profile
  - Pick a date, time slot, and fill in the booking form
  - Submit a session request

TUTOR:
  - Go to Dashboard to see incoming booking requests
  - Click Accept or Decline on each request
  - View confirmed upcoming sessions and calendar

ADMIN (Monisha S — Owner):
  - Switch role to "Admin" to unlock the admin panel
  - Monitor live calls, read message threads, manage bookings
  - Add/remove tutors, manage students, resolve issues
  - Control platform settings and commission rate

TECHNOLOGY USED
---------------
- HTML5         — Page structure and content
- CSS3          — Styling, layout (CSS Grid/Flexbox), variables
- JavaScript    — Logic, interactivity, dynamic rendering
- Google Fonts  — DM Sans + DM Serif Display typography
- No frameworks, no backend, no database required

DESIGN PATTERN
--------------
Single Page Application (SPA) — all views are on one HTML
page. JavaScript shows/hides sections to simulate navigation.

FILES IN THIS PROJECT
---------------------
app/
  index.html          ← The complete application (open this)

documentation/
  project_report.txt  ← Technical explanation for evaluation

README.txt            ← This file

====================================================
