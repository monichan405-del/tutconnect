@echo off
echo.
echo  =========================================
echo    TutorConnect - Starting Local Server
echo    Owner: Monisha S
echo  =========================================
echo.

:: Check if Node.js is installed
node --version >nul 2>&1
if errorlevel 1 (
  echo  ERROR: Node.js is not installed!
  echo  Please download and install Node.js from:
  echo  https://nodejs.org
  echo.
  pause
  exit /b
)

:: Install dependencies if not already installed
if not exist "node_modules" (
  echo  Installing dependencies for first time...
  npm install
  echo.
)

echo  Starting TutorConnect server...
echo  Open your browser and go to:
echo.
echo    http://localhost:3000         (this computer)
echo    http://YOUR-LOCAL-IP:3000     (other devices on WiFi)
echo.
echo  Admin panel: http://localhost:3000/admin
echo  Admin password: monisha2025  (change it after first login!)
echo.
echo  Press Ctrl+C to stop the server.
echo.
node server.js
pause
