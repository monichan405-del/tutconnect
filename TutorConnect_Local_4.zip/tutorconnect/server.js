// ─────────────────────────────────────────────────
//  TutorConnect  –  Local Network Server
//  Owner / Admin : Monisha S
//  Run: node server.js
//  Access on same WiFi: http://<your-ip>:3000
// ─────────────────────────────────────────────────

const express = require('express');
const session = require('express-session');
const path    = require('path');
const fs      = require('fs');
const os      = require('os');

const app  = express();
const PORT = 3000;

// ── helpers ──────────────────────────────────────
const DB_FILE = path.join(__dirname, 'data', 'db.json');

function readDB() {
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}
function writeDB(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// ── middleware ────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'monisha-tutorconnect-2025',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 8 * 60 * 60 * 1000 }   // 8 hours
}));

// ── auth middleware ───────────────────────────────
function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  res.status(403).json({ error: 'Admin access only. Please log in as Monisha S.' });
}

// ── ROUTES ────────────────────────────────────────

// Serve pages
app.get('/',          (req, res) => res.sendFile(path.join(__dirname, 'public', 'pages', 'home.html')));
app.get('/admin',     (req, res) => res.sendFile(path.join(__dirname, 'public', 'pages', 'admin.html')));
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, 'public', 'pages', 'dashboard.html')));

// ─ Auth ─
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;
  const db = readDB();
  if (password === db.adminPassword) {
    req.session.isAdmin = true;
    req.session.adminName = 'Monisha S';
    res.json({ success: true, name: 'Monisha S' });
  } else {
    res.status(401).json({ error: 'Incorrect password. Access denied.' });
  }
});

app.post('/api/admin/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/admin/check', (req, res) => {
  res.json({ isAdmin: !!(req.session && req.session.isAdmin), name: req.session.adminName || null });
});

// ─ Tutors (public) ─
app.get('/api/tutors', (req, res) => {
  const db = readDB();
  res.json(db.tutors.filter(t => t.active));
});

app.get('/api/tutors/:id', (req, res) => {
  const db = readDB();
  const t = db.tutors.find(t => t.id == req.params.id);
  t ? res.json(t) : res.status(404).json({ error: 'Not found' });
});

// ─ Bookings (public submit) ─
app.post('/api/bookings', (req, res) => {
  const db = readDB();
  const booking = {
    id: Date.now(),
    studentName: req.body.studentName,
    studentEmail: req.body.studentEmail,
    parentEmail: req.body.parentEmail || '',
    tutorId: Number(req.body.tutorId),
    tutorName: req.body.tutorName,
    subject: req.body.subject,
    date: req.body.date,
    time: req.body.time,
    notes: req.body.notes || '',
    referralCode: req.body.referralCode || '',
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  db.bookings.push(booking);
  writeDB(db);
  res.json({ success: true, booking });
});

app.get('/api/bookings/student/:email', (req, res) => {
  const db = readDB();
  res.json(db.bookings.filter(b => b.studentEmail === req.params.email));
});

// ─ Reviews (public submit) ─
app.post('/api/reviews', (req, res) => {
  const db = readDB();
  const review = {
    id: Date.now(),
    tutorId: Number(req.body.tutorId),
    author: req.body.author,
    rating: Number(req.body.rating),
    text: req.body.text,
    createdAt: new Date().toISOString()
  };
  db.reviews.push(review);
  // update tutor avg rating
  const tutorReviews = db.reviews.filter(r => r.tutorId === review.tutorId);
  const avg = tutorReviews.reduce((s, r) => s + r.rating, 0) / tutorReviews.length;
  const tutor = db.tutors.find(t => t.id === review.tutorId);
  if (tutor) { tutor.rating = Math.round(avg * 10) / 10; tutor.reviews = tutorReviews.length; }
  writeDB(db);
  res.json({ success: true });
});

// ─ Questions / Help requests (public) ─
app.post('/api/questions', (req, res) => {
  const db = readDB();
  const q = {
    id: Date.now(),
    studentName: req.body.studentName,
    studentEmail: req.body.studentEmail,
    subject: req.body.subject,
    question: req.body.question,
    status: 'open',
    adminReply: '',
    createdAt: new Date().toISOString()
  };
  db.questions.push(q);
  writeDB(db);
  res.json({ success: true, id: q.id });
});

app.get('/api/questions/student/:email', (req, res) => {
  const db = readDB();
  res.json(db.questions.filter(q => q.studentEmail === req.params.email));
});

// ─────────────────────────────────────────────────
//  ADMIN-ONLY ROUTES (all below require admin login)
// ─────────────────────────────────────────────────

// All bookings
app.get('/api/admin/bookings', requireAdmin, (req, res) => {
  res.json(readDB().bookings);
});

app.patch('/api/admin/bookings/:id', requireAdmin, (req, res) => {
  const db = readDB();
  const b = db.bookings.find(b => b.id == req.params.id);
  if (!b) return res.status(404).json({ error: 'Not found' });
  b.status = req.body.status;
  b.adminNote = req.body.adminNote || b.adminNote || '';
  writeDB(db);
  res.json({ success: true, booking: b });
});

// All tutors (admin)
app.get('/api/admin/tutors', requireAdmin, (req, res) => {
  res.json(readDB().tutors);
});

app.post('/api/admin/tutors', requireAdmin, (req, res) => {
  const db = readDB();
  const colors = [['#d4edda','#2d6a4f'],['#d4e8fa','#1a4d7a'],['#fce4d4','#993c1d'],['#e8d4fa','#533ab7'],['#faeacd','#854f0b']];
  const [bg, fg] = colors[db.tutors.length % colors.length];
  const tutor = {
    id: Date.now(),
    name: req.body.name,
    role: req.body.role || 'Tutor',
    subjects: (req.body.subjects || '').split(',').map(s => s.trim()).filter(Boolean),
    rating: 4.5, reviews: 0,
    price: Number(req.body.price) || 200,
    priceRange: req.body.priceRange || '₹200/hr',
    available: true, featured: false, active: true,
    avatar: req.body.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2),
    color: bg, acolor: fg,
    about: req.body.about || '',
    approach: req.body.approach || '',
    phone: req.body.phone || '',
    location: req.body.location || '',
    earnings: 0,
    studentReviews: []
  };
  db.tutors.push(tutor);
  writeDB(db);
  res.json({ success: true, tutor });
});

app.patch('/api/admin/tutors/:id', requireAdmin, (req, res) => {
  const db = readDB();
  const t = db.tutors.find(t => t.id == req.params.id);
  if (!t) return res.status(404).json({ error: 'Not found' });
  Object.assign(t, req.body);
  writeDB(db);
  res.json({ success: true, tutor: t });
});

app.delete('/api/admin/tutors/:id', requireAdmin, (req, res) => {
  const db = readDB();
  db.tutors = db.tutors.filter(t => t.id != req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// Students
app.get('/api/admin/students', requireAdmin, (req, res) => {
  res.json(readDB().students);
});

app.patch('/api/admin/students/:id', requireAdmin, (req, res) => {
  const db = readDB();
  const s = db.students.find(s => s.id == req.params.id);
  if (!s) return res.status(404).json({ error: 'Not found' });
  Object.assign(s, req.body);
  writeDB(db);
  res.json({ success: true });
});

// Questions / Admin replies
app.get('/api/admin/questions', requireAdmin, (req, res) => {
  res.json(readDB().questions);
});

app.patch('/api/admin/questions/:id', requireAdmin, (req, res) => {
  const db = readDB();
  const q = db.questions.find(q => q.id == req.params.id);
  if (!q) return res.status(404).json({ error: 'Not found' });
  q.adminReply = req.body.adminReply || q.adminReply;
  q.status = req.body.status || q.status;
  writeDB(db);
  res.json({ success: true, question: q });
});

// Issues
app.get('/api/admin/issues', requireAdmin, (req, res) => {
  res.json(readDB().issues);
});

app.post('/api/admin/issues', requireAdmin, (req, res) => {
  const db = readDB();
  db.issues.push({ id: Date.now(), ...req.body, status: 'open', createdAt: new Date().toISOString() });
  writeDB(db);
  res.json({ success: true });
});

app.patch('/api/admin/issues/:id', requireAdmin, (req, res) => {
  const db = readDB();
  const iss = db.issues.find(i => i.id == req.params.id);
  if (iss) Object.assign(iss, req.body);
  writeDB(db);
  res.json({ success: true });
});

// Reviews (admin view all)
app.get('/api/admin/reviews', requireAdmin, (req, res) => {
  res.json(readDB().reviews);
});

app.delete('/api/admin/reviews/:id', requireAdmin, (req, res) => {
  const db = readDB();
  db.reviews = db.reviews.filter(r => r.id != req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// Admin settings
app.get('/api/admin/settings', requireAdmin, (req, res) => {
  res.json(readDB().settings);
});

app.patch('/api/admin/settings', requireAdmin, (req, res) => {
  const db = readDB();
  Object.assign(db.settings, req.body);
  writeDB(db);
  res.json({ success: true, settings: db.settings });
});

// Change admin password
app.post('/api/admin/change-password', requireAdmin, (req, res) => {
  const { newPassword } = req.body;
  if (!newPassword || newPassword.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
  const db = readDB();
  db.adminPassword = newPassword;
  writeDB(db);
  res.json({ success: true });
});

// Stats
app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const db = readDB();
  const accepted = db.bookings.filter(b => b.status === 'accepted').length;
  const pending  = db.bookings.filter(b => b.status === 'pending').length;
  const revenue  = db.bookings.filter(b => b.status === 'accepted')
    .reduce((s, b) => { const t = db.tutors.find(t => t.id === b.tutorId); return s + (t ? t.price : 0); }, 0);
  res.json({
    tutors:    db.tutors.filter(t => t.active).length,
    students:  db.students.length,
    bookings:  db.bookings.length,
    accepted, pending,
    revenue,
    questions: db.questions.filter(q => q.status === 'open').length,
    issues:    db.issues.filter(i => i.status === 'open').length
  });
});

// ── Start ─────────────────────────────────────────
app.listen(PORT, '0.0.0.0', () => {
  const interfaces = os.networkInterfaces();
  let localIP = 'localhost';
  Object.values(interfaces).forEach(iface => {
    iface.forEach(details => {
      if (details.family === 'IPv4' && !details.internal) localIP = details.address;
    });
  });
  console.log('\n╔══════════════════════════════════════════════╗');
  console.log('║       TutorConnect  –  Running Locally       ║');
  console.log('╠══════════════════════════════════════════════╣');
  console.log(`║  Local:    http://localhost:${PORT}              ║`);
  console.log(`║  Network:  http://${localIP}:${PORT}          ║`);
  console.log('║  Admin:    /admin  (login as Monisha S)      ║');
  console.log('╚══════════════════════════════════════════════╝\n');
});
