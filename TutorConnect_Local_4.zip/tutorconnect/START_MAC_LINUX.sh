#!/bin/bash

echo ""
echo " ========================================="
echo "   TutorConnect - Starting Local Server"
echo "   Owner: Monisha S"
echo " ========================================="
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
  echo " ERROR: Node.js is not installed!"
  echo " Please download from: https://nodejs.org"
  exit 1
fi

# Install deps if needed
if [ ! -d "node_modules" ]; then
  echo " Installing dependencies for first time..."
  npm install
  echo ""
fi

echo " Starting TutorConnect..."
echo " Open your browser and go to:"
echo ""
echo "   http://localhost:3000           (this Mac/PC)"

# Try to find local IP
LOCAL_IP=$(ipconfig getifaddr en0 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}')
if [ -n "$LOCAL_IP" ]; then
  echo "   http://$LOCAL_IP:3000    (other devices on same WiFi)"
fi

echo ""
echo " Admin panel: http://localhost:3000/admin"
echo " Admin password: monisha2025  (change after first login!)"
echo ""
echo " Press Ctrl+C to stop the server."
echo ""
node server.js
